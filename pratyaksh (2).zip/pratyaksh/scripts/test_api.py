"""First-hour API test: check your key, credits, Aletheia and Eidos with real recordings.

Usage (from the project folder, after putting DETECTIF_API_KEY in .env):

  python scripts/test_api.py credits
  python scripts/test_api.py detect  my_voice.wav
  python scripts/test_api.py enroll  test_alice  enroll_clip.wav        (15-60 s, at least 10 s of speech)
  python scripts/test_api.py verify  test_alice  check_clip.wav         (3-60 s)
  python scripts/test_api.py delete  test_alice

Record clips with your phone's voice recorder or Audacity. WAV, MP3, M4A, OGG, WebM and FLAC all work.
Only record your own or a teammate's voice, with their permission.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pratyaksh.detectif import DetectifClient, DetectifError  # noqa: E402


def show(title, obj):
    print(f"\n=== {title} ===")
    print(json.dumps(obj, indent=2, default=str))


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1
    client = DetectifClient()
    cmd = argv[1]
    try:
        if cmd == "credits":
            show("Credits", client.credits())
        elif cmd == "detect":
            r = client.detect(Path(argv[2]).read_bytes(), Path(argv[2]).name)
            print(f"\nAletheia verdict: {r.verdict}  (score {r.score:.3f}; higher = more likely AI)")
            show("Raw response", r.raw)
        elif cmd == "enroll":
            r = client.enroll(argv[2], Path(argv[3]).read_bytes(), Path(argv[3]).name)
            print(f"\nEnrolled '{r.speaker_id}': {r.samples} sample(s), speech {r.speech_seconds} s")
            show("Raw response", r.raw)
        elif cmd == "verify":
            r = client.verify(argv[2], Path(argv[3]).read_bytes(), Path(argv[3]).name, detect_deepfake=True)
            print(f"\nEidos decision: {r.decision}  (similarity {r.similarity:.4f}, range -1 to 1)")
            if r.deepfake:
                print(f"Aletheia verdict: {r.deepfake.verdict}  (score {r.deepfake.score:.3f})")
            show("Raw response", r.raw)
        elif cmd == "delete":
            print("Deleted" if client.delete_speaker(argv[2]) else "No such speaker")
        else:
            print(__doc__)
            return 1
    except DetectifError as e:
        print(f"\nAPI error {e.status} ({e.code}): {e.message}")
        if e.status == 401:
            print("Check DETECTIF_API_KEY in your .env file.")
        elif e.status == 402:
            print("Out of credits.")
        elif e.status == 422:
            print("Audio problem: too short, too long, or not enough speech.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
