"""Pratyaksh - Streamlit app (verification desk + admin dashboard).

Run:  streamlit run app.py
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pandas as pd
import streamlit as st

from pratyaksh import challenge as ch
from pratyaksh import config, db, service, stages, words
from pratyaksh.detectif import MOCK_SCENARIOS, DetectifClient, DetectifError, MockClient

st.set_page_config(page_title="Pratyaksh", page_icon="🛡️", layout="wide")
db.init_db()

DECISION_STYLE = {
    "ALLOW": ("success", "ALLOW: candidate may proceed"),
    "STEP UP": ("warning", "STEP UP: extra check needed"),
    "HOLD": ("error", "HOLD: stop and check ID in person"),
    "ESCALATE": ("error", "ESCALATE: refer to the exam authority"),
}
STATUS_ICON = {"REGISTERED": "⚪", "ENROLLED": "🔵", "ACTIVE": "🟢", "PROVISIONAL": "🟡", "HOLD": "🔴",
               "ESCALATED": "🚨"}


# ----------------------------------------------------------------- client ---

def get_client():
    want_mock = st.session_state.get("use_mock", config.MOCK_MODE)
    scenario = st.session_state.get("mock_scenario", "genuine")
    if want_mock:
        client = st.session_state.get("_mock_client")
        if client is None:
            client = MockClient(scenario)
            st.session_state["_mock_client"] = client
        client.scenario = scenario
        return client
    client = st.session_state.get("_real_client")
    if client is None:
        client = DetectifClient()
        st.session_state["_real_client"] = client
    return client


def show_decision(decision: str):
    kind, text = DECISION_STYLE.get(decision, ("info", decision))
    getattr(st, kind)(f"### {text}")


def candidate_picker(label="Candidate", key="cand", statuses=None):
    cands = db.list_candidates()
    if statuses:
        cands = [c for c in cands if c["status"] in statuses]
    if not cands:
        st.info("No candidates yet. Register one first.")
        return None
    options = {f"{STATUS_ICON.get(c['status'], '')} {c['id']} · {c['name']} · {c['exam']}": c["id"] for c in cands}
    choice = st.selectbox(label, list(options), key=key)
    return db.get_candidate(options[choice])


def audio_from(label: str, key: str):
    """Record in the browser, or upload a file. Returns (bytes, filename) or (None, None)."""
    rec = st.audio_input(label, key=f"{key}_rec")
    up = st.file_uploader("…or upload a recording", type=["wav", "mp3", "m4a", "ogg", "webm", "flac"],
                          key=f"{key}_up")
    if rec is not None:
        return rec.getvalue(), "recording.wav"
    if up is not None:
        return up.getvalue(), up.name
    return None, None


# ---------------------------------------------------------------- sidebar ---

with st.sidebar:
    st.title("🛡️ Pratyaksh")
    st.caption("The same person, in person, at every stage.")
    page = st.radio("Go to", ["Verification desk", "Register & enroll", "Dashboard", "Clear a hold",
                              "Audit log", "Settings & API"], label_visibility="collapsed")
    st.divider()
    st.session_state["staff_id"] = st.text_input("Your staff ID", st.session_state.get("staff_id", "STAFF-01"))
    if config.DETECTIF_API_KEY:
        st.session_state["use_mock"] = st.toggle("Mock mode (no credits)", st.session_state.get("use_mock", False))
    else:
        st.session_state["use_mock"] = True
        st.caption("No API key in .env, so mock mode is on.")
    if st.session_state["use_mock"]:
        st.session_state["mock_scenario"] = st.selectbox(
            "Mock scenario", list(MOCK_SCENARIOS), format_func=lambda k: MOCK_SCENARIOS[k],
            index=list(MOCK_SCENARIOS).index(st.session_state.get("mock_scenario", "genuine")))

client = get_client()
staff = st.session_state["staff_id"] or "STAFF-01"
if client.is_mock:
    st.warning("**MOCK MODE**: results are simulated, not from DetectifAI. Switch it off for real checks.")


# ------------------------------------------------------- verification desk ---

if page == "Verification desk":
    st.header("Verification desk")
    st.caption("Candidate reads a fresh sentence. Pratyaksh checks the words, Aletheia (real voice?) and "
               "Eidos (same person?), then the policy engine decides.")

    cand = candidate_picker(statuses=["ENROLLED", "ACTIVE", "PROVISIONAL", "HOLD", "ESCALATED"])
    if cand:
        chain = stages.chain(cand["exam"])
        labels = {s.label + ("  · anchor" if s.anchor else "") + ("  · final gate" if s.final_gate else ""): s.key
                  for s in chain}
        stage_key = labels[st.selectbox("Stage", list(labels))]
        stage = stages.get_stage(cand["exam"], stage_key)
        hoarse = st.checkbox("Candidate says they are unwell (hoarse mode: record 20-30 seconds)")
        if cand["status"] in ("HOLD", "ESCALATED"):
            st.error(f"This candidate is on {cand['status']}. Checks are recorded, but clear the case first.")

        if st.button("Start check: show a new sentence", type="primary"):
            try:
                st.session_state["challenge"] = service.start_check(cand["id"], stage_key)
                st.session_state.pop("last_result", None)
            except service.PratyakshError as e:
                st.error(str(e))

        chal = st.session_state.get("challenge")
        if chal and chal["candidate_id"] == cand["id"] and chal["stage"] == stage_key and not chal.get("done"):
            issued = datetime.fromisoformat(chal["issued_at"])
            expires = (issued + timedelta(seconds=chal["ttl_seconds"])).astimezone()
            st.markdown("#### Ask the candidate to read this aloud:")
            st.markdown(f"<div style='font-size:1.6rem;line-height:1.5;padding:1rem;border:2px solid #4a90d9;"
                        f"border-radius:10px'>{chal['text']}</div>", unsafe_allow_html=True)
            st.caption(f"Single use. Expires at {expires.strftime('%H:%M:%S')}"
                       + (" · Anchor stage: this recording becomes the reference voice for later stages."
                          if stage.anchor else ""))
            col1, col2 = st.columns(2)
            with col1:
                audio, fname = audio_from("Record the candidate", f"chk{chal['id']}")
            with col2:
                photo = st.camera_input("Live photo (kept as Pratyaksh's own face record)", key=f"ph{chal['id']}")
            if st.button("Submit for checking", type="primary", disabled=audio is None):
                with st.spinner("Checking with DetectifAI…"):
                    try:
                        res = service.run_check(client, chal["id"], audio, fname, staff, hoarse=hoarse,
                                                photo=photo.getvalue() if photo else None)
                        st.session_state["last_result"] = res
                        chal["done"] = True
                    except (service.PratyakshError, DetectifError) as e:
                        st.error(str(e))

        res = st.session_state.get("last_result")
        if res and res["candidate"] == cand["id"]:
            st.divider()
            show_decision(res["decision"])
            st.markdown(f"**Next step:** {res['next_step']}")
            c1, c2, c3 = st.columns(3)
            with c1:
                sim = res["eidos"]["similarity"]
                st.metric("Eidos: same person?", res["eidos"]["decision"].replace("_", " ").upper(),
                          help="Similarity runs from -1 to 1. Higher = more alike. Not a percentage.")
                st.progress(min(max((sim + 1) / 2, 0.0), 1.0), text=f"similarity {sim:.3f} vs {res['reference']}")
            with c2:
                v, s = res["aletheia"]["verdict"], res["aletheia"]["score"]
                st.metric("Aletheia: real voice?", (v or "not run").upper())
                if s is not None:
                    st.progress(min(max(s, 0.0), 1.0), text=f"AI-likelihood score {s:.3f} (higher = more likely AI)")
            with c3:
                w = res["words"]
                st.metric("Words check", "PASS" if w["ok"] else ("FAIL" if w["ok"] is False else "NOT CHECKED"))
                st.caption(w["note"])
                if w.get("transcript"):
                    st.caption(f"Heard: “{w['transcript']}”")
            if res["cross_hits"]:
                st.error("**One voice, many identities:** this voice also matches " + ", ".join(
                    f"{h['id']} ({h['name']}, similarity {h['similarity']:.2f}, {h['why']})" for h in res["cross_hits"]))
            st.markdown("**Why:**")
            for r in res["reasons"]:
                st.markdown(f"- {r}")
            st.caption(f"Attempt {res['attempt']} · {res['stage']} · DetectifAI operation IDs: "
                       f"{', '.join(o for o in res['operation_ids'] if o)}"
                       + (" · SIMULATED" if res["mock"] else ""))
            if res["decision"] == "STEP UP" and "Retry" in res["next_step"]:
                st.info("Press **Start check** again for a new sentence.")


# -------------------------------------------------------- register & enroll ---

elif page == "Register & enroll":
    st.header("Register & enroll")
    tab1, tab2 = st.tabs(["1. Register a candidate", "2. Voice enrollment (5 styles)"])

    with tab1:
        with st.form("register", clear_on_submit=True):
            c1, c2 = st.columns(2)
            roll = c1.text_input("Roll / application number *")
            name = c2.text_input("Full name *")
            exam = c1.selectbox("Exam", stages.EXAMS)
            centre = c2.text_input("Exam centre", "Bengaluru-C01")
            phone = c1.text_input("Registered mobile")
            device = c2.text_input("Device ID used to register (optional)")
            minor = st.checkbox("Candidate is under 18")
            consent = st.text_input("Parent / guardian giving consent (required if under 18)")
            st.caption("Consent: the voice is used only for identity checks in this exam cycle and deleted "
                       "after admissions or recruitment end.")
            if st.form_submit_button("Register", type="primary"):
                try:
                    service.register(roll, name, exam, centre, phone, device, minor, consent, staff)
                    st.success(f"Registered {roll}. Now enroll their voice in tab 2.")
                except service.PratyakshError as e:
                    st.error(str(e))

    with tab2:
        cand = candidate_picker(key="enroll_cand")
        if cand:
            n = db.accepted_count(cand["id"])
            st.progress(min(n / 5, 1.0), text=f"{n} of 5 samples accepted "
                        f"(at least {ch.MIN_ENROLLMENT_SAMPLES} needed)")
            done_styles = {e["style"] for e in db.enrollments(cand["id"]) if e["accepted"] and e["kind"] == "registration"}
            for style in ch.ENROLLMENT_STYLES:
                done = style["key"] in done_styles
                with st.expander(("✅ " if done else "") + style["title"], expanded=not done and n < 5):
                    st.markdown(f"**How:** {style['how']}")
                    st.info(style["script"])
                    st.caption("Needs 15-60 seconds of audio. Read the whole passage.")
                    if not done:
                        audio, fname = audio_from("Record", f"en_{cand['id']}_{style['key']}")
                        if st.button("Save this sample", key=f"save_{style['key']}", disabled=audio is None):
                            with st.spinner("Checking and enrolling…"):
                                try:
                                    r = service.enroll_sample(client, cand["id"], style["key"], audio, fname, staff)
                                except service.PratyakshError as e:
                                    r = {"accepted": False, "reason": str(e)}
                            if r["accepted"]:
                                st.success(r["reason"])
                                if r.get("cross_hits"):
                                    st.error("This enrollment voice matches other roll numbers: " +
                                             ", ".join(h["id"] for h in r["cross_hits"]) + ". Escalated.")
                                st.rerun()
                            else:
                                st.error(r["reason"])


# ----------------------------------------------------------------- dashboard ---

elif page == "Dashboard":
    st.header("Dashboard")
    cands = db.list_candidates()
    alerts = db.list_alerts()
    overdue = service.overdue_provisionals()
    m = st.columns(5)
    m[0].metric("Candidates", len(cands))
    m[1].metric("Open alerts", len(alerts))
    m[2].metric("On HOLD", sum(c["status"] == "HOLD" for c in cands))
    m[3].metric("Escalated", sum(c["status"] == "ESCALATED" for c in cands))
    m[4].metric("Provisional overdue", len(overdue))

    st.subheader("Open alerts")
    if alerts:
        for a in alerts:
            icon = "🚨" if a["level"] == "ESCALATE" else ("🔴" if a["level"] == "HOLD" else "ℹ️")
            c1, c2 = st.columns([6, 1])
            c1.markdown(f"{icon} **{a['candidate_id']}** · {a['kind'].replace('_', ' ')} · {a['detail']}  \n"
                        f"<span style='color:gray;font-size:0.8rem'>{a['created_at']}</span>", unsafe_allow_html=True)
            if c2.button("Resolve", key=f"res{a['id']}"):
                db.resolve_alert(a["id"])
                db.log(staff, "resolve_alert", a["candidate_id"], {"alert_id": a["id"]})
                st.rerun()
    else:
        st.caption("No open alerts.")

    st.subheader("Candidates")
    if cands:
        df = pd.DataFrame([{"Status": f"{STATUS_ICON.get(c['status'], '')} {c['status']}", "Roll": c["id"],
                            "Name": c["name"], "Exam": c["exam"], "Centre": c["centre"],
                            "Samples": db.accepted_count(c["id"]), "Illness excuses": c["excuse_count"],
                            "Re-check due": c["provisional_due"] or ""} for c in cands])
        st.dataframe(df, hide_index=True, use_container_width=True)

        st.subheader("Candidate timeline")
        cand = candidate_picker("Show timeline for", key="tl_cand")
        if cand:
            tl = service.timeline(cand["id"])
            cols = st.columns(len(tl["chain"]))
            for col, s in zip(cols, tl["chain"]):
                checks = tl["checks"][s.key]
                last = checks[-1]["decision"] if checks else None
                icon = {"ALLOW": "🟢", "STEP UP": "🟡", "HOLD": "🔴", "ESCALATE": "🚨"}.get(last, "⚪")
                col.markdown(f"{icon} **{s.label}**" + ("  \n_anchor_" if s.anchor else "")
                             + ("  \n_final gate_" if s.final_gate else ""))
                col.caption(last or "not yet")
            for s in tl["chain"]:
                for c in tl["checks"][s.key]:
                    with st.expander(f"{s.label} · attempt {c['attempt']} · {c['decision']} · {c['created_at']}"):
                        a, b = st.columns([2, 1])
                        a.markdown(f"**Sentence:** {c['challenge']}")
                        sim_txt = f"{c['eidos_similarity']:.3f}" if c["eidos_similarity"] is not None else "n/a"
                        a.markdown(f"**Eidos:** {c['eidos_decision']} (similarity {sim_txt}) vs `{c['eidos_ref']}`")
                        a.markdown(f"**Aletheia:** {c['deepfake_verdict']} (score {c['deepfake_score']})")
                        a.markdown(f"**Words:** {'not checked' if c['words_ok'] is None else ('pass' if c['words_ok'] else 'fail')}"
                                   + (f" · heard “{c['transcript']}”" if c["transcript"] else ""))
                        for r in c["reasons"]:
                            a.markdown(f"- {r}")
                        a.caption(f"Staff {c['staff_id']} · mode {c['mode']}" + (" · SIMULATED" if c["mock"] else ""))
                        if c["audio_path"]:
                            b.audio(c["audio_path"])
                        if c["photo_path"]:
                            try:
                                b.image(c["photo_path"], caption="Pratyaksh live photo", width=200)
                            except Exception:
                                b.caption("Photo could not be displayed")
    else:
        st.caption("No candidates yet.")


# --------------------------------------------------------------- clear hold ---

elif page == "Clear a hold":
    st.header("Clear a hold")
    st.caption("After an in-person ID check, two different officers can clear a HOLD. The candidate becomes "
               "PROVISIONAL until a voice re-check passes. Every override is signed in the audit log.")
    cand = candidate_picker(statuses=["HOLD", "PROVISIONAL"], key="clear_cand")
    if cand:
        with st.form("clear"):
            o1 = st.text_input("Officer 1 ID", staff)
            o2 = st.text_input("Officer 2 ID (must be different)")
            note = st.text_area("What was checked in person (face vs Pratyaksh photo, fingerprint, documents)")
            prov = st.checkbox("Keep PROVISIONAL until a voice re-check passes", value=True)
            if st.form_submit_button("Clear hold", type="primary"):
                try:
                    service.manual_clear(cand["id"], o1, o2, note, prov)
                    st.success("Cleared and logged.")
                except service.PratyakshError as e:
                    st.error(str(e))
    st.divider()
    st.subheader("Exam authority: resolve an escalated case")
    cand2 = candidate_picker(statuses=["ESCALATED"], key="auth_cand")
    if cand2:
        with st.form("authority"):
            auth = st.text_input("Authority officer ID")
            outcome = st.radio("Outcome", ["cleared", "confirmed_fraud"], horizontal=True)
            note2 = st.text_area("Findings")
            if st.form_submit_button("Record outcome"):
                try:
                    service.authority_resolve(cand2["id"], auth or "AUTHORITY", outcome, note2)
                    st.success("Recorded.")
                except service.PratyakshError as e:
                    st.error(str(e))


# ---------------------------------------------------------------- audit log ---

elif page == "Audit log":
    st.header("Audit log")
    ok, bad = db.verify_log_chain()
    if ok:
        st.success("Log chain intact: no entry has been edited or deleted.")
    else:
        st.error(f"Log chain broken at entry {bad}: the log has been tampered with.")
    st.subheader("Overrides per staff member")
    oc = db.override_counts()
    st.dataframe(pd.DataFrame(oc) if oc else pd.DataFrame(columns=["staff_id", "overrides"]), hide_index=True)
    st.caption("An unusually high count can point to insider help.")
    st.subheader("All actions")
    st.dataframe(pd.DataFrame(db.staff_log()), hide_index=True, use_container_width=True)


# ------------------------------------------------------------ settings & API ---

elif page == "Settings & API":
    st.header("Settings & API")
    st.markdown(f"- **Mode:** {'MOCK (simulated)' if client.is_mock else 'LIVE DetectifAI'}")
    st.markdown(f"- **Words check:** {words.status_text()}")
    st.markdown(f"- **Retries before HOLD:** {config.MAX_RETRIES} · **Cross-check shortlist:** "
                f"{config.CROSS_CHECK_LIMIT} candidates · **Sentence expiry:** {config.CHALLENGE_TTL_SECONDS} s "
                f"(anchor {config.ANCHOR_CHALLENGE_TTL_SECONDS} s)")
    st.markdown(f"- **Weak-match cut-off:** {config.EIDOS_LOW_CONFIDENCE_SIMILARITY or 'off (set after testing)'}")
    if st.button("Check DetectifAI credits"):
        try:
            st.json(client.credits())
        except DetectifError as e:
            st.error(str(e))

    st.subheader("Tell DetectifAI a result was wrong")
    with st.form("fb"):
        op = st.text_input("Operation ID (shown under each result)")
        correct = st.radio("Was the result correct?", ["yes", "no"], horizontal=True)
        label = st.selectbox("What was the recording really?", ["", "real", "fake"])
        note = st.text_input("Note (optional)")
        if st.form_submit_button("Send feedback"):
            try:
                st.json(client.feedback(op, correct == "yes", label or None, note or None))
            except DetectifError as e:
                st.error(str(e))

    st.subheader("Delete a candidate (privacy)")
    cand = candidate_picker(key="del_cand")
    if cand and st.button(f"Delete {cand['id']} and their voice data", type="secondary"):
        for spk in (db.reg_speaker(cand), db.anchor_speaker(cand)):
            try:
                client.delete_speaker(spk)
            except DetectifError:
                pass
        db.delete_candidate(cand["id"])
        db.log(staff, "delete_candidate", cand["id"], "voice data deleted")
        st.success("Deleted.")
        st.rerun()
