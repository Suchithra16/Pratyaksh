"""Smoke tests for the FastAPI backend and the Streamlit app (mock mode)."""
from pathlib import Path

from tests.conftest import make_wav


def test_api_flow():
    from fastapi.testclient import TestClient
    import api
    c = TestClient(api.app)
    assert c.get("/health").json()["mock"] is True
    r = c.post("/candidates", json={"roll": "API1", "name": "Api Student", "exam": "NEET", "centre": "C9",
                                    "is_minor": True, "consent_by": "Parent"})
    assert r.status_code == 200, r.text
    for style in ["normal", "numbers", "questions"]:
        r = c.post("/candidates/API1/enroll", data={"style": style},
                   files={"file": ("a.wav", make_wav(18, hash(style) % 100), "audio/wav")})
        assert r.json()["accepted"], r.text
    ch = c.post("/checks/start", json={"roll": "API1", "stage": "exam_hall"}).json()
    r = c.post(f"/checks/{ch['id']}", data={"staff_id": "S1"}, files={"file": ("b.wav", make_wav(18, 7), "audio/wav")})
    assert r.json()["decision"] == "ALLOW", r.text
    tl = c.get("/candidates/API1/timeline").json()
    assert tl["chain"][0]["anchor"] is True
    assert c.get("/audit/verify").json()["intact"] is True


def test_streamlit_pages_render():
    from streamlit.testing.v1 import AppTest
    for page in ["Verification desk", "Register & enroll", "Dashboard", "Clear a hold", "Audit log",
                 "Settings & API"]:
        at = AppTest.from_file(str(Path(__file__).resolve().parent.parent / "app.py"), default_timeout=60)
        at.run()
        at.sidebar.radio[0].set_value(page).run()
        assert not at.exception, (page, at.exception)


def test_dashboard_with_data():
    from streamlit.testing.v1 import AppTest
    from pratyaksh import service
    from pratyaksh.detectif import MockClient
    cl = MockClient("genuine")
    service.register("D1", "Dash One", "UPSC", "C1", phone="111")
    for i, s in enumerate(["normal", "numbers", "questions"]):
        service.enroll_sample(cl, "D1", s, make_wav(18, i))
    chal = service.start_check("D1", "prelims")
    service.run_check(cl, chal["id"], make_wav(18, 9), photo=_jpeg())
    cl.scenario = "impostor"
    chal = service.start_check("D1", "training_academy")
    service.run_check(cl, chal["id"], make_wav(8, 10))
    for page in ["Dashboard", "Audit log", "Clear a hold", "Verification desk"]:
        at = AppTest.from_file(str(Path(__file__).resolve().parent.parent / "app.py"), default_timeout=60)
        at.run()
        at.sidebar.radio[0].set_value(page).run()
        assert not at.exception, (page, at.exception)


def _jpeg():
    import io
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (40, 30), (120, 160, 200)).save(buf, "JPEG")
    return buf.getvalue()
