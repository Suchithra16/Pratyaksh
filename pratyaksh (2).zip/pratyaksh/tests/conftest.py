import io
import math
import os
import random
import sys
import tempfile
import wave
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["PRATYAKSH_DATA_DIR"] = tempfile.mkdtemp(prefix="pratyaksh-test-")
os.environ["PRATYAKSH_MOCK"] = "1"
os.environ["WORDS_CHECK"] = "off"


def make_wav(seconds: float, seed: int = 0) -> bytes:
    rate = 16000
    rnd = random.Random(seed)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        frames = bytearray()
        for i in range(int(seconds * rate)):
            v = int(8000 * math.sin(2 * math.pi * 220 * i / rate) + rnd.randint(-500, 500))
            frames += v.to_bytes(2, "little", signed=True)
        w.writeframes(bytes(frames))
    return buf.getvalue()


@pytest.fixture
def wav():
    return make_wav


@pytest.fixture(autouse=True)
def fresh_db():
    from pratyaksh import config, db
    if config.DB_PATH.exists():
        config.DB_PATH.unlink()
    db.init_db()
    yield
