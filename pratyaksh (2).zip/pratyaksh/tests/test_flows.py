"""End-to-end flows in MOCK mode (no credits used)."""

import pytest

from pratyaksh import challenge, db, policy, service, words
from pratyaksh.detectif import MockClient
from pratyaksh.policy import ALLOW, ESCALATE, HOLD, STEP_UP, Evidence, decide


def enroll_full(client, roll, wav, seed=0):
    for i, style in enumerate(["normal", "numbers", "questions"]):
        r = service.enroll_sample(client, roll, style, wav(18, seed + i))
        assert r["accepted"], r


def reg(roll, centre="C1", phone="", exam="JEE"):
    return service.register(roll, f"Student {roll}", exam, centre, phone=phone, is_minor=True, consent_by="Parent")


# ------------------------------------------------------------ policy ---

def test_policy_allow():
    d = decide(Evidence(deepfake_verdict="real", eidos_decision="match", eidos_similarity=0.8))
    assert d.decision == ALLOW


def test_policy_clone_escalates():
    d = decide(Evidence(deepfake_verdict="fake", deepfake_score=0.9, eidos_decision="match"))
    assert d.decision == ESCALATE


def test_policy_ai_voice_holds():
    d = decide(Evidence(deepfake_verdict="fake", eidos_decision="no_match"))
    assert d.decision == HOLD


def test_policy_mismatch_retries_then_holds():
    assert decide(Evidence(attempt=1, eidos_decision="no_match", deepfake_verdict="real")).decision == STEP_UP
    assert decide(Evidence(attempt=3, eidos_decision="no_match", deepfake_verdict="real")).decision == HOLD


def test_policy_final_gate_no_retry():
    d = decide(Evidence(attempt=1, final_gate=True, eidos_decision="no_match", deepfake_verdict="real"))
    assert d.decision == HOLD


def test_policy_replay():
    d = decide(Evidence(attempt=3, words_checked=True, words_ok=False, eidos_decision="match",
                        deepfake_verdict="real"))
    assert d.decision == HOLD


def test_policy_sore_throat_then_repeat():
    d = decide(Evidence(hoarse_mode=True, eidos_decision="no_match", deepfake_verdict="real"))
    assert d.decision == STEP_UP and d.provisional and d.new_status == "PROVISIONAL"
    d2 = decide(Evidence(hoarse_mode=True, excuses_before=1, eidos_decision="match", deepfake_verdict="real"))
    assert d2.decision == ESCALATE


def test_policy_solver():
    d = decide(Evidence(eidos_decision="match", deepfake_verdict="real", cross_hits=[{"id": "X2"}]))
    assert d.decision == ESCALATE


# ---------------------------------------------------------- challenge ---

def test_challenges_unique_and_long():
    seen = {challenge.new_challenge() for _ in range(200)}
    assert len(seen) == 200
    assert len(challenge.new_challenge(long=True).split()) > len(challenge.new_challenge().split()) * 2


def test_words_normalise():
    assert words.similarity("Is the code 4 7 1 9?", "is the code four seven one nine") == 1.0
    assert words.similarity("Kavya left the green umbrella", "something else entirely") < 0.5


# -------------------------------------------------------------- flows ---

def test_minor_needs_consent():
    with pytest.raises(service.PratyakshError):
        service.register("R0", "A", "JEE", "C1", is_minor=True, consent_by="")


def test_enrollment_rejects_short_clip(wav):
    reg("R1")
    r = service.enroll_sample(MockClient(), "R1", "normal", wav(5))
    assert not r["accepted"]


def test_honest_candidate_full_chain(wav):
    client = MockClient("genuine")
    reg("R1")
    enroll_full(client, "R1", wav)
    assert db.get_candidate("R1")["status"] == "ENROLLED"
    c = service.start_check("R1", "exam_hall")
    r = service.run_check(client, c["id"], wav(18, 50))
    assert r["decision"] == ALLOW
    assert db.accepted_count("R1", "anchor") == 1
    c = service.start_check("R1", "college_reporting")
    r = service.run_check(client, c["id"], wav(8, 51))
    assert r["decision"] == ALLOW and "anchor" in r["reference"]


def test_proxy_caught_at_reporting(wav):
    client = MockClient("genuine")
    reg("R2")
    enroll_full(client, "R2", wav)
    c = service.start_check("R2", "exam_hall")
    service.run_check(client, c["id"], wav(18, 60))
    client.scenario = "impostor"  # a different person turns up at the final gate
    c = service.start_check("R2", "college_reporting")
    r = service.run_check(client, c["id"], wav(8, 61))
    assert r["decision"] == HOLD
    assert db.get_candidate("R2")["status"] == "HOLD"


def test_solver_flagged_at_exam_hall(wav):
    client = MockClient("genuine")
    reg("A1", phone="999")
    enroll_full(client, "A1", wav, seed=10)
    reg("A2", phone="999")
    enroll_full(client, "A2", wav, seed=20)
    client.scenario = "solver"
    c = service.start_check("A2", "exam_hall")
    r = service.run_check(client, c["id"], wav(18, 70))
    assert r["decision"] == ESCALATE and r["cross_hits"][0]["id"] == "A1"


def test_clone_escalates(wav):
    client = MockClient("genuine")
    reg("R3")
    enroll_full(client, "R3", wav)
    client.scenario = "ai_clone"
    c = service.start_check("R3", "exam_hall")
    r = service.run_check(client, c["id"], wav(18, 80))
    assert r["decision"] == ESCALATE
    assert db.accepted_count("R3", "anchor") == 0  # an AI clip is never saved as the anchor


def test_sore_throat_protocol(wav):
    client = MockClient("genuine")
    reg("R4")
    enroll_full(client, "R4", wav)
    c = service.start_check("R4", "exam_hall")
    service.run_check(client, c["id"], wav(18, 90))
    client.scenario = "impostor"
    c = service.start_check("R4", "counselling_docs")
    r = service.run_check(client, c["id"], wav(25, 91), hoarse=True)
    assert r["decision"] == STEP_UP
    cand = db.get_candidate("R4")
    assert cand["status"] == "PROVISIONAL" and cand["provisional_due"]
    c = service.start_check("R4", "college_reporting")
    r = service.run_check(client, c["id"], wav(25, 92), hoarse=True)
    assert r["decision"] == ESCALATE


def test_challenge_single_use(wav):
    client = MockClient("genuine")
    reg("R5")
    enroll_full(client, "R5", wav)
    c = service.start_check("R5", "exam_hall")
    service.run_check(client, c["id"], wav(18, 100))
    with pytest.raises(service.PratyakshError):
        service.run_check(client, c["id"], wav(18, 101))


def test_override_needs_two_officers(wav):
    reg("R6")
    db.update_candidate("R6", status="HOLD")
    with pytest.raises(service.PratyakshError):
        service.manual_clear("R6", "S1", "S1", "Checked Aadhaar and admit card in person")
    service.manual_clear("R6", "S1", "S2", "Checked Aadhaar and admit card in person")
    assert db.get_candidate("R6")["status"] == "PROVISIONAL"


def test_log_chain_detects_tampering():
    db.log("S1", "a", "R", "x")
    db.log("S1", "b", "R", "y")
    assert db.verify_log_chain() == (True, None)
    with db.conn() as c:
        c.execute("UPDATE staff_log SET detail='tampered' WHERE id=1")
    ok, bad = db.verify_log_chain()
    assert not ok and bad == 1


def test_demo_solver_caught_at_enrollment(wav):
    # Racket enrolls proxy C's voice for roll B; C later enrolls for another roll with the same phone.
    client = MockClient("genuine")
    reg("B", phone="777")
    enroll_full(client, "B", wav, seed=200)
    reg("B2", phone="777")
    client.scenario = "solver"
    r = service.enroll_sample(client, "B2", "normal", wav(18, 300))
    assert r["accepted"] and r["cross_hits"][0]["id"] == "B"
    assert db.get_candidate("B2")["status"] == "ESCALATED"
