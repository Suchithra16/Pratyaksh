# Pratyaksh

**The same person, in person, at every stage of an exam.**

Exam rackets now morph admit-card photos with AI and swap Aadhaar records, so proxy candidates pass face and fingerprint checks. Pratyaksh adds a second identity that rackets can't swap: the voice. At every stage, from the JEE, NEET or UPSC exam hall to college reporting or the training academy, the candidate reads a fresh random sentence and Pratyaksh checks:

- **Words:** did they say the sentence on screen? (blocks replayed recordings)
- **Aletheia** (DetectifAI): is it a real human voice, not an AI clone?
- **Eidos** (DetectifAI): is it the same person as the voice of whoever wrote the exam?
- **Cross-candidate:** does the same voice appear under other roll numbers? (professional solvers)

A policy engine turns the results into **ALLOW**, **STEP UP**, **HOLD** or **ESCALATE**. A score is evidence, not proof: nobody is rejected automatically.

Built for the CMRIT × DetectifAI Hackathon (25–26 Nov 2026).

---

## 1. Set up (10 minutes)

You need Python 3.10 or newer.

```bash
# from inside the pratyaksh folder
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Mac / Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

Then make your settings file:

```bash
# Windows
copy .env.example .env
# Mac / Linux
cp .env.example .env
```

Open `.env` and paste your key from **platform.detectif.ai → API keys** after `DETECTIF_API_KEY=`.
Without a key, the app runs in **mock mode** (simulated results, no credits used, clearly labelled on screen).

## 2. First-hour API test (do this first)

Record two clips of your own voice with your phone: one of 20 seconds, one of 6 seconds. Then:

```bash
python scripts/test_api.py credits
python scripts/test_api.py detect  short.m4a
python scripts/test_api.py enroll  test_me  long.m4a
python scripts/test_api.py verify  test_me  short.m4a
python scripts/test_api.py delete  test_me
```

If `verify` says `match`, everything works. Note the credits used per call.

## 3. Run the app

```bash
streamlit run app.py
```

It opens in your browser. Pages:

| Page | What it's for |
| --- | --- |
| Verification desk | The exam-desk screen: pick candidate and stage, show a sentence, record, see the decision |
| Register & enroll | Register a candidate (parent consent if under 18) and record 5 voice styles |
| Dashboard | Alerts, candidate list, and each candidate's stage-by-stage timeline with audio and photos |
| Clear a hold | Two different officers clear a HOLD after an in-person check; the authority resolves escalations |
| Audit log | Every action, with a tamper check (the log is hash-chained) and overrides per staff member |
| Settings & API | Credits, feedback to DetectifAI, delete a candidate's voice data |

Optional backend for other systems (same logic, REST API):

```bash
uvicorn api:app --reload --port 8000     # docs at http://localhost:8000/docs
```

### Optional: words check

```bash
pip install faster-whisper
```

The first check downloads the Whisper model (about 140 MB). Without it the app still works and shows "words: not checked".

## 4. Demo script

Use only your own and teammates' voices, with permission.

1. **Honest candidate:** register and enroll teammate A (at least 3 styles; 15–60 seconds each). A at *Exam hall* → ALLOW. A at *College reporting* → ALLOW (compared with A's exam-hall voice).
2. **Proxy caught at the final gate:** register roll number B, but teammate C (the "proxy") records B's enrollment, as a racket would. C does B's *Exam hall* check → ALLOW, and C's voice becomes B's anchor. Then teammate B, the real candidate, does *College reporting* → HOLD.
3. **Professional solver:** register a second roll number with the same phone number as B, and have C enroll again → flagged at enrollment: same voice as roll number B (ESCALATE).
4. **Proxy without racket help:** a fourth person tries A's *Exam hall* check → STEP UP (retry), then HOLD.
5. **AI clone:** play an AI-generated clip of A's voice (made with A's permission) → Aletheia flags it.
6. **Sore throat:** tick "unwell" → hoarse mode; a fail gives PROVISIONAL with a re-check date; a second excuse → ESCALATE.
7. Show the **Audit log** (chain intact) and the **Dashboard** timeline.

No API credits left, or the Wi-Fi fails? Switch on mock mode in the sidebar and pick a scenario, but say clearly that it is simulated.

## 5. How it works

```
Audio (desk recording or upload)
   │
   ├─ Words check (Whisper, local)          did they say the sentence?
   ├─ Eidos verify + Aletheia (one call)    same person? real voice?
   ├─ Cross-candidate verify (anchor stage) same voice under other roll numbers?
   ▼
Policy engine → ALLOW | STEP UP | HOLD | ESCALATE → alerts, candidate status, signed log
```

- **Enrollment:** 5 styles (normal, slow numbers, questions, loud, mother tongue). Each new sample must match the earlier ones, so disguised enrollments are rejected. The first sample is checked against other candidates with the same phone, device or centre.
- **Anchor:** the exam-hall recording (about 15–20 seconds, three sentences) is enrolled as the reference voice. Every later stage is compared with whoever actually wrote the exam, so a racket that enrolled the proxy at registration is still caught when the real student reports to college.
- **Final gates** (college reporting, training academy) allow no retries.
- **Sore-throat protocol:** hoarse mode, then the face is checked against Pratyaksh's own live photo plus fingerprint by two officers → PROVISIONAL until a voice re-check passes; a second excuse escalates.
- **Speaker IDs** in DetectifAI: `EXAM.ROLL.reg` (registration) and `EXAM.ROLL.anchor` (exam hall).

## 6. Run the tests

```bash
python -m pytest -q
```

They run in mock mode (no credits) and cover the policy engine, every demo scenario, the API and all app pages.

## 7. Honest limits

- Voice is less accurate than fingerprints; Pratyaksh is an extra layer, not a replacement.
- Live voice changers are the biggest threat; they rely on Aletheia catching them and on supervised devices.
- Eidos compares one-to-one, so cross-candidate matching covers a shortlist (same phone, device or centre), not every candidate nationally.
- Similar-sounding siblings are a real risk; combine voice with face and fingerprint.
- Thresholds should be tuned from your own test clips (`EIDOS_LOW_CONFIDENCE_SIMILARITY` in `.env`).

## Folder layout

```
app.py                 Streamlit app (desk + dashboard)
api.py                 FastAPI backend
pratyaksh/
  config.py            settings from .env
  detectif.py          DetectifAI client (real + mock)
  challenge.py         random sentences and enrollment scripts
  words.py             speech-to-text words check
  stages.py            JEE / NEET / UPSC stage chains
  policy.py            ALLOW / STEP UP / HOLD / ESCALATE rules
  service.py           workflows used by app and API
  db.py                SQLite storage and hash-chained audit log
scripts/test_api.py    first-hour API test
tests/                 automated tests (mock mode)
```
