"""Pratyaksh workflows: registration, voice enrollment, stage checks and overrides.

Both the Streamlit app and the FastAPI backend call these functions, so the logic lives in one place.
"""

from __future__ import annotations

import sqlite3
import time
from datetime import datetime, timedelta, timezone

from . import challenge as ch
from . import config, db, policy, stages, words
from .detectif import DetectifError, wav_duration


class PratyakshError(Exception):
    pass


def _save(folder, name: str, data: bytes | None) -> str:
    if not data:
        return ""
    path = folder / name
    path.write_bytes(data)
    return str(path)


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S-%f")


# --------------------------------------------------------- registration ---

def register(roll: str, name: str, exam: str, centre: str, phone: str = "", device_id: str = "",
             is_minor: bool = False, consent_by: str = "", staff_id: str = "system") -> dict:
    if exam not in stages.EXAMS:
        raise PratyakshError(f"Exam must be one of {stages.EXAMS}")
    if not roll.strip() or not name.strip():
        raise PratyakshError("Roll number and name are required.")
    if is_minor and not consent_by.strip():
        raise PratyakshError("Candidate is under 18: a parent or guardian must give consent.")
    if db.get_candidate(roll.strip()):
        raise PratyakshError(f"Roll number {roll} is already registered.")
    cand = db.add_candidate(roll, name, exam, centre, phone, device_id, is_minor, consent_by)
    db.log(staff_id, "register", cand["id"], {"exam": exam, "centre": centre, "minor": is_minor,
                                               "consent_by": consent_by})
    return cand


# ----------------------------------------------------------- enrollment ---

def enroll_sample(client, roll: str, style: str, audio: bytes, filename: str = "clip.wav",
                  staff_id: str = "system") -> dict:
    """Add one enrollment recording. Checks it is a real voice, consistent with earlier samples
    (stops disguised enrollments) and, on the first sample, not already enrolled under another roll number."""
    cand = db.get_candidate(roll)
    if not cand:
        raise PratyakshError("Unknown roll number.")
    if db.accepted_count(roll) >= 5:
        raise PratyakshError("Already has 5 enrollment samples (the DetectifAI maximum).")
    dur = wav_duration(audio)
    if dur is not None and dur < 15:
        return {"accepted": False, "reason": f"Too short: {dur:.1f} s. Enrollment needs 15-60 s."}
    if dur is not None and dur > 60:
        return {"accepted": False, "reason": f"Too long: {dur:.1f} s. Keep it under 60 s."}

    speaker = db.reg_speaker(cand)
    audio_path = _save(config.AUDIO_DIR, f"{db.clean_id(roll)}-enroll-{style}-{_stamp()}.wav", audio)
    first = db.accepted_count(roll) == 0
    similarity = None
    out: dict = {"mock": client.is_mock}

    try:
        if first:
            df = client.detect(audio, filename)
            verdict = df.verdict if df else None
        else:
            # Consistency check: the new sample must match the samples already enrolled.
            v = client.verify(speaker, audio, filename, detect_deepfake=True)
            verdict = v.deepfake.verdict if v.deepfake else None
            similarity = v.similarity
            if v.decision != "match":
                reason = (f"Does not match this candidate's earlier samples (similarity {v.similarity:.2f}). "
                          "Re-record in a natural voice; a disguised enrollment is rejected.")
                db.add_enrollment(roll, "registration", style, False, reason, None, similarity, v.operation_id,
                                  audio_path)
                db.log(staff_id, "enroll_rejected", roll, {"style": style, "reason": "inconsistent"})
                return {**out, "accepted": False, "reason": reason, "similarity": similarity}
        if verdict == "fake":
            reason = "Aletheia flagged this recording as AI-generated. Enrollment refused."
            db.add_enrollment(roll, "registration", style, False, reason, None, similarity, None, audio_path)
            db.add_alert(roll, policy.ESCALATE, "ai_enrollment", reason)
            db.log(staff_id, "enroll_rejected", roll, {"style": style, "reason": "ai_voice"})
            return {**out, "accepted": False, "reason": reason}

        res = client.enroll(speaker, audio, filename, display_name=f"{cand['name']} ({roll})")
    except DetectifError as e:
        return {**out, "accepted": False, "reason": f"DetectifAI error {e.status}: {e.message}"}

    db.add_enrollment(roll, "registration", style, True, "", res.speech_seconds, similarity, res.operation_id,
                      audio_path)
    db.log(staff_id, "enroll_sample", roll, {"style": style, "samples": res.samples})
    out.update(accepted=True, reason="Sample accepted", samples=res.samples, speech_seconds=res.speech_seconds,
               similarity=similarity)

    # One voice, many identities - checked at enrollment so a solver is caught before the exam.
    if first:
        hits = cross_check(client, cand, audio, filename)
        out["cross_hits"] = hits
        if hits:
            ids = ", ".join(h["id"] for h in hits)
            db.add_alert(roll, policy.ESCALATE, "duplicate_enrollment",
                         f"Enrollment voice matches other roll numbers: {ids}")
            db.update_candidate(roll, status="ESCALATED")

    if db.accepted_count(roll) >= ch.MIN_ENROLLMENT_SAMPLES and db.get_candidate(roll)["status"] == "REGISTERED":
        db.update_candidate(roll, status="ENROLLED")
    out["enrolled"] = db.accepted_count(roll) >= ch.MIN_ENROLLMENT_SAMPLES
    return out


def cross_check(client, cand: dict, audio: bytes, filename: str) -> list[dict]:
    hits = []
    for other in db.shortlist(cand, config.CROSS_CHECK_LIMIT):
        try:
            v = client.verify(db.reg_speaker(other), audio, filename, detect_deepfake=False, role="cross")
        except DetectifError:
            continue
        if v.decision == "match":
            hits.append({"id": other["id"], "name": other["name"], "similarity": round(v.similarity, 4),
                         "why": other.get("why_shortlisted", "")})
    return hits


# --------------------------------------------------------------- checks ---

def start_check(roll: str, stage_key: str) -> dict:
    cand = db.get_candidate(roll)
    if not cand:
        raise PratyakshError("Unknown roll number.")
    if db.accepted_count(roll) < ch.MIN_ENROLLMENT_SAMPLES:
        raise PratyakshError(f"Candidate needs at least {ch.MIN_ENROLLMENT_SAMPLES} enrollment samples first.")
    stage = stages.get_stage(cand["exam"], stage_key)
    for _ in range(5):
        text = ch.new_challenge(long=stage.anchor)
        try:
            c = db.issue_challenge(roll, stage_key, text, stage.anchor)
            break
        except sqlite3.IntegrityError:  # sentence used before: never reuse
            continue
    ttl = config.ANCHOR_CHALLENGE_TTL_SECONDS if stage.anchor else config.CHALLENGE_TTL_SECONDS
    c["ttl_seconds"] = ttl
    c["stage_label"] = stage.label
    return c


def _expired(chal: dict) -> bool:
    issued = datetime.fromisoformat(chal["issued_at"])
    ttl = config.ANCHOR_CHALLENGE_TTL_SECONDS if chal["long"] else config.CHALLENGE_TTL_SECONDS
    return datetime.now(timezone.utc) - issued > timedelta(seconds=ttl)


def run_check(client, challenge_id: int, audio: bytes, filename: str = "clip.wav", staff_id: str = "system",
              hoarse: bool = False, photo: bytes | None = None) -> dict:
    chal = db.get_challenge(challenge_id)
    if not chal:
        raise PratyakshError("Unknown challenge.")
    if chal["used"]:
        raise PratyakshError("This sentence was already used. Start a new check.")
    if _expired(chal):
        db.mark_challenge_used(challenge_id)
        raise PratyakshError("The sentence expired before the recording arrived. Start a new check.")
    db.mark_challenge_used(challenge_id)

    roll = chal["candidate_id"]
    cand = db.get_candidate(roll)
    stage = stages.get_stage(cand["exam"], chal["stage"])
    attempt = db.attempts_at(roll, stage.key) + 1

    # Reference voice: the anchor (whoever wrote the exam) once it exists; registration before that.
    anchor_ready = db.accepted_count(roll, "anchor") > 0
    if stage.anchor or not anchor_ready:
        ref = db.reg_speaker(cand)
        ref_label = "registration voice"
    else:
        ref = db.anchor_speaker(cand)
        ref_label = "exam-hall voice (anchor)"

    stamp = _stamp()
    audio_path = _save(config.AUDIO_DIR, f"{db.clean_id(roll)}-{stage.key}-{stamp}.wav", audio)
    photo_path = _save(config.PHOTO_DIR, f"{db.clean_id(roll)}-{stage.key}-{stamp}.jpg", photo)

    t0 = time.time()
    wc = words.check(audio, chal["text"])
    try:
        v = client.verify(ref, audio, filename, detect_deepfake=True)
    except DetectifError as e:
        raise PratyakshError(f"DetectifAI error {e.status}: {e.message}") from e
    if v.deepfake is None:  # combined call didn't return a deepfake result: run Aletheia separately
        try:
            v.deepfake = client.detect(audio, filename)
        except DetectifError:
            pass
    ops = [v.operation_id] + ([v.deepfake.operation_id] if v.deepfake and v.deepfake.operation_id else [])

    hits = []
    if stage.anchor:
        hits = cross_check(client, cand, audio, filename)

    ev = policy.Evidence(
        attempt=attempt,
        max_retries=config.MAX_RETRIES,
        final_gate=stage.final_gate,
        hoarse_mode=hoarse,
        excuses_before=cand["excuse_count"] or 0,
        words_checked=wc["checked"],
        words_ok=wc["ok"],
        deepfake_verdict=v.deepfake.verdict if v.deepfake else None,
        deepfake_score=v.deepfake.score if v.deepfake else None,
        eidos_decision=v.decision,
        eidos_similarity=v.similarity,
        low_confidence_similarity=config.EIDOS_LOW_CONFIDENCE_SIMILARITY,
        cross_hits=hits,
    )
    d = policy.decide(ev)
    if not stage.anchor and not anchor_ready:
        d.reasons.append("Note: no exam-hall anchor yet, so this was compared with the registration voice")

    # The anchor stage saves whoever actually wrote the exam as the reference for every later stage.
    anchor_note = None
    if stage.anchor and ev.deepfake_verdict != "fake" and db.accepted_count(roll, "anchor") < 5:
        try:
            r = client.enroll(db.anchor_speaker(cand), audio, filename, display_name=f"{cand['name']} anchor")
            db.add_enrollment(roll, "anchor", stage.key, True, "", r.speech_seconds, v.similarity,
                              r.operation_id, audio_path)
            anchor_note = "Exam-hall voice saved as the anchor for later stages"
        except DetectifError as e:
            anchor_note = f"Anchor not saved ({e.message}); later stages will use the registration voice"
        d.reasons.append(anchor_note)

    check_id = db.add_check(
        candidate_id=roll, stage=stage.key, attempt=attempt, mode="hoarse" if hoarse else "normal",
        challenge=chal["text"], transcript=wc["transcript"], words_score=wc["score"],
        words_ok=None if wc["ok"] is None else int(wc["ok"]),
        deepfake_verdict=ev.deepfake_verdict, deepfake_score=ev.deepfake_score, eidos_ref=ref,
        eidos_decision=v.decision, eidos_similarity=v.similarity, cross_hits=hits, decision=d.decision,
        reasons=d.reasons, next_step=d.next_step, staff_id=staff_id, photo_path=photo_path,
        audio_path=audio_path, operation_ids=[o for o in ops if o], mock=int(client.is_mock))

    for level, kind, detail in d.alerts:
        db.add_alert(roll, level, kind, f"[{stage.label}] {detail}")

    updates: dict = {}
    if hoarse:
        updates["excuse_count"] = (cand["excuse_count"] or 0) + 1
    if d.provisional:
        updates["provisional_due"] = (datetime.now() + timedelta(days=config.PROVISIONAL_DAYS)).date().isoformat()
    if d.new_status and cand["status"] != "ESCALATED":  # only an authority clears ESCALATED
        if d.new_status == "ACTIVE" and cand["status"] == "PROVISIONAL" and hoarse:
            pass  # still provisional until a normal voice re-check passes
        else:
            updates["status"] = d.new_status
            if d.new_status == "ACTIVE":
                updates["provisional_due"] = None
    if d.new_status == "ESCALATED":
        updates["status"] = "ESCALATED"
    db.update_candidate(roll, **updates)

    db.log(staff_id, "check", roll, {"stage": stage.key, "attempt": attempt, "decision": d.decision,
                                     "check_id": check_id, "hoarse": hoarse})

    return {
        "check_id": check_id, "candidate": roll, "stage": stage.label, "attempt": attempt,
        "decision": d.decision, "reasons": d.reasons, "next_step": d.next_step, "reference": ref_label,
        "eidos": {"decision": v.decision, "similarity": v.similarity},
        "aletheia": {"verdict": ev.deepfake_verdict, "score": ev.deepfake_score},
        "words": wc, "cross_hits": hits, "mock": client.is_mock,
        "duration": wav_duration(audio), "seconds_taken": round(time.time() - t0, 1),
        "operation_ids": ops,
    }


# ------------------------------------------------------------ overrides ---

def manual_clear(roll: str, officer_1: str, officer_2: str, note: str, provisional: bool = True) -> None:
    """After an in-person ID check, two different officers can clear a HOLD.
    Every override is signed in the tamper-evident log. ESCALATED cases need the exam authority."""
    cand = db.get_candidate(roll)
    if not cand:
        raise PratyakshError("Unknown roll number.")
    if not officer_1.strip() or not officer_2.strip() or officer_1.strip() == officer_2.strip():
        raise PratyakshError("Two different officer IDs are required.")
    if cand["status"] == "ESCALATED":
        raise PratyakshError("Escalated cases can only be cleared by the exam authority.")
    if len(note.strip()) < 10:
        raise PratyakshError("Write what was checked in person (at least 10 characters).")
    fields = {"status": "PROVISIONAL" if provisional else "ACTIVE"}
    if provisional:
        fields["provisional_due"] = (datetime.now() + timedelta(days=config.PROVISIONAL_DAYS)).date().isoformat()
    db.update_candidate(roll, **fields)
    db.log(officer_1, "override_clear", roll, {"second_officer": officer_2, "note": note,
                                              "provisional": provisional})


def authority_resolve(roll: str, authority_id: str, outcome: str, note: str) -> None:
    """Exam authority closes an escalated case: outcome = cleared | confirmed_fraud."""
    if outcome not in ("cleared", "confirmed_fraud"):
        raise PratyakshError("Outcome must be 'cleared' or 'confirmed_fraud'.")
    db.update_candidate(roll, status="ACTIVE" if outcome == "cleared" else "HOLD")
    db.log(authority_id, f"authority_{outcome}", roll, {"note": note})


def overdue_provisionals() -> list[dict]:
    today = datetime.now().date().isoformat()
    return [c for c in db.list_candidates()
            if c["status"] == "PROVISIONAL" and c["provisional_due"] and c["provisional_due"] < today]


def timeline(roll: str) -> dict:
    cand = db.get_candidate(roll)
    if not cand:
        raise PratyakshError("Unknown roll number.")
    chain = stages.chain(cand["exam"])
    checks = db.checks_for(roll)
    by_stage = {s.key: [c for c in checks if c["stage"] == s.key] for s in chain}
    return {"candidate": cand, "enrollments": db.enrollments(roll), "chain": chain, "checks": by_stage,
            "alerts": [a for a in db.list_alerts(True) if a["candidate_id"] == roll]}
