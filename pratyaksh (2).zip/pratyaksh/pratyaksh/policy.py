"""The policy engine: turns check results into one of four decisions.

  ALLOW     candidate proceeds
  STEP UP   retry with a new sentence, or the sore-throat fallback (provisional pass)
  HOLD      stop this stage; invigilator checks ID in person
  ESCALATE  send to the exam authority (solver, AI clone, repeat excuses)

Rules that never change: no automatic rejection, every decision lists its reasons,
and a score is treated as evidence, not proof.
"""

from __future__ import annotations

from dataclasses import dataclass, field

ALLOW, STEP_UP, HOLD, ESCALATE = "ALLOW", "STEP UP", "HOLD", "ESCALATE"


@dataclass
class Evidence:
    attempt: int = 1                       # 1 = first try at this stage
    max_retries: int = 2
    final_gate: bool = False               # college reporting / training academy: no retries
    hoarse_mode: bool = False              # candidate says they are unwell
    excuses_before: int = 0                # illness excuses used earlier in the chain
    words_checked: bool = False
    words_ok: bool | None = None
    deepfake_verdict: str | None = None    # "real" | "fake" | None
    deepfake_score: float | None = None
    eidos_decision: str | None = None      # "match" | "no_match" | None
    eidos_similarity: float | None = None
    low_confidence_similarity: float | None = None
    cross_hits: list = field(default_factory=list)  # [{"id":..., "similarity":...}]


@dataclass
class Decision:
    decision: str
    reasons: list[str]
    next_step: str
    new_status: str | None = None          # candidate status to set
    alerts: list[tuple[str, str, str]] = field(default_factory=list)  # (level, kind, detail)
    provisional: bool = False


def decide(ev: Evidence) -> Decision:
    retries_left = (not ev.final_gate) and ev.attempt <= ev.max_retries
    reasons: list[str] = []
    alerts: list[tuple[str, str, str]] = []

    # 0. A second illness excuse anywhere in the chain is escalated, whatever the scores say.
    if ev.hoarse_mode and ev.excuses_before >= 1:
        reasons.append(f"Illness excuse used again ({ev.excuses_before + 1} times in this candidate's chain)")
        alerts.append((ESCALATE, "repeat_excuse", reasons[-1]))
        return Decision(ESCALATE, reasons, "Refer to the exam authority. Do a full in-person ID check now.",
                        "ESCALATED", alerts)

    # 1. AI-generated voice.
    if ev.deepfake_verdict == "fake":
        score = f" (score {ev.deepfake_score:.2f})" if ev.deepfake_score is not None else ""
        if ev.eidos_decision == "match":
            reasons.append(f"Aletheia: AI-generated voice{score} that ALSO matches the enrolled voice - "
                           "likely a clone of the real candidate")
            alerts.append((ESCALATE, "ai_clone", reasons[-1]))
            return Decision(ESCALATE, reasons, "Stop the check. Refer to the exam authority with this evidence.",
                            "ESCALATED", alerts)
        reasons.append(f"Aletheia: AI-generated voice{score}")
        alerts.append((HOLD, "ai_voice", reasons[-1]))
        return Decision(HOLD, reasons, "Invigilator does a full in-person ID check. Case logged.", "HOLD", alerts)

    # 2. One voice, many identities.
    if ev.cross_hits:
        ids = ", ".join(h["id"] for h in ev.cross_hits)
        reasons.append(f"Same voice also matches other roll numbers: {ids}")
        alerts.append((ESCALATE, "solver", f"Likely professional solver: voice matches {ids}"))
        return Decision(ESCALATE, reasons, "Refer to the exam authority. Hold every linked roll number for "
                        "in-person checks.", "ESCALATED", alerts)

    # 3. The sentence on screen was not spoken (possible replay of an old recording).
    if ev.words_checked and ev.words_ok is False:
        reasons.append("Words check: the challenge sentence was not spoken - possible replayed recording")
        if retries_left:
            return Decision(STEP_UP, reasons, "Retry with a new sentence. Read it aloud clearly.")
        alerts.append((HOLD, "replay_suspected", reasons[-1]))
        return Decision(HOLD, reasons, "Invigilator does a full in-person ID check. Case logged.", "HOLD", alerts)

    # 4. Voice does not match the reference.
    if ev.eidos_decision == "no_match":
        sim = f" (similarity {ev.eidos_similarity:.2f})" if ev.eidos_similarity is not None else ""
        if ev.hoarse_mode:
            reasons.append(f"Eidos: no match in hoarse mode{sim}; candidate reports being unwell")
            alerts.append(("INFO", "provisional", "Provisional pass after illness excuse; voice re-check due"))
            return Decision(
                STEP_UP, reasons,
                "Fallback: two officers compare the face with Pratyaksh's own photo from the previous stage, "
                "plus fingerprint. Status is PROVISIONAL until a voice re-check passes.",
                "PROVISIONAL", alerts, provisional=True)
        reasons.append(f"Eidos: voice does not match the reference{sim}")
        if retries_left:
            return Decision(STEP_UP, reasons, "Retry with a new sentence (background noise or nerves can "
                            "cause this).")
        if ev.final_gate:
            reasons.append("Final gate: this voice must match whoever wrote the exam")
        alerts.append((HOLD, "voice_mismatch", reasons[0]))
        return Decision(HOLD, reasons, "Stop this stage. Invigilator checks ID in person; possible proxy. "
                        "Case logged.", "HOLD", alerts)

    # 5. A match, but a weak one (only if you set a low-confidence cut-off from your tests).
    if (ev.eidos_decision == "match" and ev.low_confidence_similarity is not None
            and ev.eidos_similarity is not None and ev.eidos_similarity < ev.low_confidence_similarity):
        reasons.append(f"Eidos: weak match (similarity {ev.eidos_similarity:.2f} is below "
                       f"{ev.low_confidence_similarity:.2f})")
        if retries_left:
            return Decision(STEP_UP, reasons, "Retry with a new sentence.")
        alerts.append((HOLD, "weak_match", reasons[-1]))
        return Decision(HOLD, reasons, "Invigilator checks ID in person.", "HOLD", alerts)

    if ev.eidos_decision != "match":
        reasons.append("No voice result was returned")
        return Decision(STEP_UP, reasons, "Retry with a new sentence.")

    # 6. All checks passed.
    reasons.append("Eidos: voice matches the reference")
    reasons.append("Aletheia: real human voice" if ev.deepfake_verdict == "real" else "Aletheia: not run")
    if ev.words_checked:
        reasons.append("Words check: correct sentence spoken")
    if ev.hoarse_mode:
        reasons.append("Passed in hoarse mode")
        alerts.append(("INFO", "hoarse_pass", "Passed in hoarse mode; quick voice re-check recommended"))
    return Decision(ALLOW, reasons, "Candidate may proceed.", "ACTIVE", alerts)
