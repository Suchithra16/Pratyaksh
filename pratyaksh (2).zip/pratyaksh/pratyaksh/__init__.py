"""Pratyaksh: the same person, in person, at every stage of an exam."""

__version__ = "0.1.0"
