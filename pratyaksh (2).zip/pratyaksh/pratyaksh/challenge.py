"""Challenge sentences and enrollment scripts.

Challenge sentences are random and single-use, so nobody can prepare a recording in advance.
They mix names, numbers, places and objects (many different speech sounds) and pair a statement
with a question (pitch rises and falls). No AI model is needed: word lists plus templates.
"""

import secrets

_rng = secrets.SystemRandom()

NAMES = ["Kavya", "Arjun", "Meera", "Rohan", "Fatima", "Joseph", "Lakshmi", "Vikram", "Ananya",
         "Imran", "Divya", "Harish", "Pooja", "Suresh", "Nandini", "Tenzing", "Gurpreet", "Zoya"]
COLOURS = ["green", "yellow", "purple", "orange", "silver", "maroon", "sky blue", "brown", "white"]
OBJECTS = ["umbrella", "bicycle", "notebook", "water bottle", "school bag", "lunch box", "calculator",
           "blanket", "flower pot", "cricket bat", "train ticket", "torch"]
PLACES = ["the old library", "Gate number four", "the railway station", "the bus depot", "the temple steps",
          "the vegetable market", "the hospital canteen", "the post office", "the lake road", "the hostel mess"]
TIMES = ["at seven in the morning", "just after lunch", "before the rain", "late on Thursday",
         "early on Sunday", "during the power cut", "after the second bell"]

STATEMENTS = [
    "{name} left the {colour} {object} near {place} {time}.",
    "{name} counted {number} {colour} pebbles beside {place}.",
    "The {colour} {object} belongs to {name}, who lives near {place}.",
    "{name} wrote the number {number} on the {colour} {object}.",
]
QUESTIONS = [
    "Was it really there {time}?",
    "Did {name2} see it near {place2}?",
    "Why would anyone carry a {object2} to {place2}?",
    "Is the code {number2} or something else?",
]


def _number() -> str:
    # Spoken as separate digits, e.g. "4 7 1 9" -> varied sounds, hard to pre-record.
    return " ".join(str(_rng.randint(1, 9)) for _ in range(4))


def _pair() -> str:
    names = _rng.sample(NAMES, 2)
    places = _rng.sample(PLACES, 2)
    objects = _rng.sample(OBJECTS, 2)
    fill = dict(
        name=names[0], name2=names[1], colour=_rng.choice(COLOURS), object=objects[0], object2=objects[1],
        place=places[0], place2=places[1], time=_rng.choice(TIMES), number=_number(), number2=_number(),
    )
    return f"{_rng.choice(STATEMENTS).format(**fill)} {_rng.choice(QUESTIONS).format(**fill)}"


def new_challenge(long: bool = False) -> str:
    """A fresh challenge. `long=True` (anchor stage) gives about 15-20 seconds of speech,
    long enough to also enroll the clip as the exam-hall reference voice."""
    parts = 3 if long else 1
    return " ".join(_pair() for _ in range(parts))


# Five enrollment styles capture the person's range (Eidos allows up to 5 samples per speaker).
# Each must give 15-60 s of audio with at least 10 s of speech, so the scripts are deliberately long.
ENROLLMENT_STYLES = [
    {
        "key": "normal",
        "title": "1. Normal reading",
        "how": "Read at your normal pace and volume.",
        "script": ("Every morning the city wakes up slowly. Shopkeepers open their shutters, buses fill with "
                   "students, and the smell of fresh coffee drifts across the road. I usually walk to the bus "
                   "stop, check the time on my phone, and think about the day ahead. Some days are busy and "
                   "some are quiet, but each one teaches me something new."),
    },
    {
        "key": "numbers",
        "title": "2. Slow numbers",
        "how": "Read slowly and clearly, with a short pause between numbers.",
        "script": ("My numbers are: four, seven, two, nine, one. Then eight, three, six, zero, five. "
                   "Again: nine, nine, four, two. Then one, six, eight, three, seven. "
                   "Finally: five, zero, two, eight, four, one."),
    },
    {
        "key": "questions",
        "title": "3. Questions",
        "how": "Read like you are really asking. Let your voice rise at the end.",
        "script": ("Did you see the yellow bus near the market at seven? Was the library open on Sunday? "
                   "Who left the green umbrella at the gate? Are we meeting before lunch or after? "
                   "Have you finished the chapter on electricity yet? Why is the canteen so crowded today?"),
    },
    {
        "key": "loud",
        "title": "4. Loud and clear",
        "how": "Speak loudly, as if answering roll call in a big hall.",
        "script": ("Present, sir! Present, madam! My name is called, and I answer loud and clear so the whole "
                   "hall can hear me. Roll number one hundred and twenty three, present! I am ready for the "
                   "exam, my admit card is with me, and I have my pen and my pencil. Present!"),
    },
    {
        "key": "mother_tongue",
        "title": "5. Your own language",
        "how": "Speak for about 20 seconds in your mother tongue (Kannada, Hindi, Tamil, Telugu, or any "
               "language): introduce yourself and describe your home town.",
        "script": "(Speak freely in your own language for about 20 seconds.)",
    },
]

# How many enrollment samples must be accepted before the candidate counts as enrolled.
MIN_ENROLLMENT_SAMPLES = 3
