"""Settings for Pratyaksh.

Values come from environment variables (or a .env file next to app.py).
Copy .env.example to .env and fill in your DetectifAI API key.
"""

import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:  # python-dotenv is optional
    pass

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("PRATYAKSH_DATA_DIR", ROOT / "data"))
AUDIO_DIR = DATA_DIR / "audio"
PHOTO_DIR = DATA_DIR / "photos"
DB_PATH = DATA_DIR / "pratyaksh.db"

for folder in (DATA_DIR, AUDIO_DIR, PHOTO_DIR):
    folder.mkdir(parents=True, exist_ok=True)

DETECTIF_API_KEY = os.getenv("DETECTIF_API_KEY", "").strip()
DETECTIF_BASE_URL = os.getenv("DETECTIF_BASE_URL", "https://platform.detectif.ai").rstrip("/")

# MOCK mode returns simulated results without calling DetectifAI (no credits used).
# It is switched on automatically when no API key is set.
MOCK_MODE = os.getenv("PRATYAKSH_MOCK", "").lower() in ("1", "true", "yes") or not DETECTIF_API_KEY

# How long a challenge sentence stays valid, in seconds (includes the time to press record).
CHALLENGE_TTL_SECONDS = int(os.getenv("CHALLENGE_TTL_SECONDS", "60"))
ANCHOR_CHALLENGE_TTL_SECONDS = int(os.getenv("ANCHOR_CHALLENGE_TTL_SECONDS", "120"))

# Retries with a new sentence before a mismatch becomes HOLD.
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "2"))

# Optional extra caution: a "match" with similarity below this is treated as borderline (STEP UP).
# Leave empty until you have tuned it from your own test clips. Similarity runs from -1 to 1.
_low = os.getenv("EIDOS_LOW_CONFIDENCE_SIMILARITY", "").strip()
EIDOS_LOW_CONFIDENCE_SIMILARITY = float(_low) if _low else None

# How many other candidates to compare against for "one voice, many identities".
CROSS_CHECK_LIMIT = int(os.getenv("CROSS_CHECK_LIMIT", "5"))

# Words check (speech-to-text). Needs: pip install faster-whisper
WORDS_CHECK_ENABLED = os.getenv("WORDS_CHECK", "auto").lower()  # auto | on | off
WORDS_MATCH_THRESHOLD = float(os.getenv("WORDS_MATCH_THRESHOLD", "0.8"))
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "base.en")

# Days allowed for the voice re-check after a provisional (sore throat) pass.
PROVISIONAL_DAYS = int(os.getenv("PROVISIONAL_DAYS", "10"))
