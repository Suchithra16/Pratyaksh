"""SQLite storage. One file: data/pratyaksh.db

The staff log is hash-chained: each entry stores the hash of the one before it, so editing or
deleting an old entry breaks the chain and `verify_log_chain()` reports it.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS candidates (
    id TEXT PRIMARY KEY,              -- roll number
    name TEXT NOT NULL,
    exam TEXT NOT NULL,               -- JEE | NEET | UPSC
    centre TEXT,
    phone TEXT,
    device_id TEXT,
    is_minor INTEGER DEFAULT 0,
    consent_by TEXT,                  -- parent/guardian name for minors
    status TEXT DEFAULT 'REGISTERED', -- REGISTERED | ENROLLED | ACTIVE | PROVISIONAL | HOLD | ESCALATED
    provisional_due TEXT,
    excuse_count INTEGER DEFAULT 0,
    voice_exempt INTEGER DEFAULT 0,   -- speech disability: face + fingerprint instead
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS enrollments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id TEXT,
    kind TEXT,                        -- registration | anchor
    style TEXT,
    accepted INTEGER,
    reason TEXT,
    speech_seconds REAL,
    similarity REAL,
    operation_id TEXT,
    audio_path TEXT,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id TEXT,
    stage TEXT,
    text TEXT UNIQUE,
    long INTEGER,
    issued_at TEXT,
    used INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id TEXT,
    stage TEXT,
    attempt INTEGER,
    mode TEXT,                        -- normal | hoarse
    challenge TEXT,
    transcript TEXT,
    words_score REAL,
    words_ok INTEGER,                 -- 1 / 0 / NULL (not checked)
    deepfake_verdict TEXT,
    deepfake_score REAL,
    eidos_ref TEXT,
    eidos_decision TEXT,
    eidos_similarity REAL,
    reg_decision TEXT,
    reg_similarity REAL,
    cross_hits TEXT,                  -- JSON list
    decision TEXT,                    -- ALLOW | STEP UP | HOLD | ESCALATE
    reasons TEXT,                     -- JSON list
    next_step TEXT,
    staff_id TEXT,
    photo_path TEXT,
    audio_path TEXT,
    operation_ids TEXT,               -- JSON list
    mock INTEGER,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    candidate_id TEXT,
    level TEXT,                       -- HOLD | ESCALATE | INFO
    kind TEXT,
    detail TEXT,
    resolved INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS staff_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    staff_id TEXT,
    action TEXT,
    candidate_id TEXT,
    detail TEXT,
    created_at TEXT,
    prev_hash TEXT,
    hash TEXT
);
"""


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def conn():
    c = sqlite3.connect(config.DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init_db() -> None:
    with conn() as c:
        c.executescript(SCHEMA)


def _rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


# ------------------------------------------------------------- speakers ---

def clean_id(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.:-]", "-", text.strip())[:40]


def reg_speaker(candidate: dict) -> str:
    return f"{candidate['exam']}.{clean_id(candidate['id'])}.reg"


def anchor_speaker(candidate: dict) -> str:
    return f"{candidate['exam']}.{clean_id(candidate['id'])}.anchor"


# ----------------------------------------------------------- candidates ---

def add_candidate(roll: str, name: str, exam: str, centre: str = "", phone: str = "", device_id: str = "",
                  is_minor: bool = False, consent_by: str = "") -> dict:
    with conn() as c:
        c.execute(
            "INSERT INTO candidates (id, name, exam, centre, phone, device_id, is_minor, consent_by, created_at)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (roll.strip(), name.strip(), exam, centre.strip(), phone.strip(), device_id.strip(),
             int(is_minor), consent_by.strip(), now()),
        )
    return get_candidate(roll.strip())


def get_candidate(roll: str) -> dict | None:
    with conn() as c:
        row = c.execute("SELECT * FROM candidates WHERE id=?", (roll,)).fetchone()
    return dict(row) if row else None


def list_candidates() -> list[dict]:
    with conn() as c:
        return _rows(c.execute("SELECT * FROM candidates ORDER BY created_at DESC"))


def update_candidate(roll: str, **fields) -> None:
    if not fields:
        return
    keys = ", ".join(f"{k}=?" for k in fields)
    with conn() as c:
        c.execute(f"UPDATE candidates SET {keys} WHERE id=?", (*fields.values(), roll))


def delete_candidate(roll: str) -> None:
    with conn() as c:
        for table in ("enrollments", "challenges", "checks", "alerts"):
            c.execute(f"DELETE FROM {table} WHERE candidate_id=?", (roll,))
        c.execute("DELETE FROM candidates WHERE id=?", (roll,))


def shortlist(candidate: dict, limit: int) -> list[dict]:
    """Other enrolled candidates to compare against for 'one voice, many identities'.
    Cheap signals first (same phone or device anywhere), then same centre and exam."""
    with conn() as c:
        same_contact = _rows(c.execute(
            "SELECT * FROM candidates WHERE id != ? AND status != 'REGISTERED' AND "
            "((phone != '' AND phone = ?) OR (device_id != '' AND device_id = ?))",
            (candidate["id"], candidate.get("phone") or "", candidate.get("device_id") or "")))
        same_centre = _rows(c.execute(
            "SELECT * FROM candidates WHERE id != ? AND status != 'REGISTERED' AND exam = ? AND centre = ? "
            "ORDER BY created_at DESC",
            (candidate["id"], candidate["exam"], candidate.get("centre") or "")))
    seen, out = set(), []
    for row in same_contact + same_centre:
        if row["id"] not in seen:
            seen.add(row["id"])
            row["why_shortlisted"] = "same phone/device" if row in same_contact else "same centre"
            out.append(row)
    return out[:limit]


# ---------------------------------------------------------- enrollments ---

def add_enrollment(candidate_id: str, kind: str, style: str, accepted: bool, reason: str = "",
                   speech_seconds: float | None = None, similarity: float | None = None,
                   operation_id: str | None = None, audio_path: str = "") -> None:
    with conn() as c:
        c.execute(
            "INSERT INTO enrollments (candidate_id, kind, style, accepted, reason, speech_seconds, similarity,"
            " operation_id, audio_path, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (candidate_id, kind, style, int(accepted), reason, speech_seconds, similarity, operation_id,
             audio_path, now()))


def enrollments(candidate_id: str) -> list[dict]:
    with conn() as c:
        return _rows(c.execute("SELECT * FROM enrollments WHERE candidate_id=? ORDER BY id", (candidate_id,)))


def accepted_count(candidate_id: str, kind: str = "registration") -> int:
    with conn() as c:
        return c.execute("SELECT COUNT(*) FROM enrollments WHERE candidate_id=? AND kind=? AND accepted=1",
                         (candidate_id, kind)).fetchone()[0]


# ----------------------------------------------------------- challenges ---

def issue_challenge(candidate_id: str, stage: str, text: str, long: bool) -> dict:
    with conn() as c:
        cur = c.execute("INSERT INTO challenges (candidate_id, stage, text, long, issued_at) VALUES (?,?,?,?,?)",
                        (candidate_id, stage, text, int(long), now()))
        cid = cur.lastrowid
    return get_challenge(cid)


def get_challenge(challenge_id: int) -> dict | None:
    with conn() as c:
        row = c.execute("SELECT * FROM challenges WHERE id=?", (challenge_id,)).fetchone()
    return dict(row) if row else None


def mark_challenge_used(challenge_id: int) -> None:
    with conn() as c:
        c.execute("UPDATE challenges SET used=1 WHERE id=?", (challenge_id,))


# --------------------------------------------------------------- checks ---

def add_check(**fields) -> int:
    for key in ("cross_hits", "reasons", "operation_ids"):
        if key in fields and not isinstance(fields[key], str):
            fields[key] = json.dumps(fields[key])
    fields.setdefault("created_at", now())
    cols = ", ".join(fields)
    qs = ", ".join("?" for _ in fields)
    with conn() as c:
        cur = c.execute(f"INSERT INTO checks ({cols}) VALUES ({qs})", tuple(fields.values()))
        return cur.lastrowid


def checks_for(candidate_id: str) -> list[dict]:
    with conn() as c:
        rows = _rows(c.execute("SELECT * FROM checks WHERE candidate_id=? ORDER BY id", (candidate_id,)))
    for r in rows:
        for key in ("cross_hits", "reasons", "operation_ids"):
            r[key] = json.loads(r[key]) if r.get(key) else []
    return rows


def attempts_at(candidate_id: str, stage: str) -> int:
    with conn() as c:
        return c.execute("SELECT COUNT(*) FROM checks WHERE candidate_id=? AND stage=?",
                         (candidate_id, stage)).fetchone()[0]


def all_checks(limit: int = 200) -> list[dict]:
    with conn() as c:
        return _rows(c.execute("SELECT * FROM checks ORDER BY id DESC LIMIT ?", (limit,)))


# --------------------------------------------------------------- alerts ---

def add_alert(candidate_id: str, level: str, kind: str, detail: str) -> None:
    with conn() as c:
        c.execute("INSERT INTO alerts (candidate_id, level, kind, detail, created_at) VALUES (?,?,?,?,?)",
                  (candidate_id, level, kind, detail, now()))


def list_alerts(include_resolved: bool = False) -> list[dict]:
    q = "SELECT * FROM alerts" + ("" if include_resolved else " WHERE resolved=0") + " ORDER BY id DESC"
    with conn() as c:
        return _rows(c.execute(q))


def resolve_alert(alert_id: int) -> None:
    with conn() as c:
        c.execute("UPDATE alerts SET resolved=1 WHERE id=?", (alert_id,))


# ------------------------------------------------------------ staff log ---

def _hash(prev: str, staff: str, action: str, cand: str, detail: str, ts: str) -> str:
    return hashlib.sha256("|".join([prev, staff, action, cand, detail, ts]).encode()).hexdigest()


def log(staff_id: str, action: str, candidate_id: str = "", detail: str | dict = "") -> None:
    if not isinstance(detail, str):
        detail = json.dumps(detail, default=str)
    ts = now()
    with conn() as c:
        row = c.execute("SELECT hash FROM staff_log ORDER BY id DESC LIMIT 1").fetchone()
        prev = row["hash"] if row else "GENESIS"
        h = _hash(prev, staff_id, action, candidate_id, detail, ts)
        c.execute("INSERT INTO staff_log (staff_id, action, candidate_id, detail, created_at, prev_hash, hash)"
                  " VALUES (?,?,?,?,?,?,?)", (staff_id, action, candidate_id, detail, ts, prev, h))


def staff_log(limit: int = 300) -> list[dict]:
    with conn() as c:
        return _rows(c.execute("SELECT * FROM staff_log ORDER BY id DESC LIMIT ?", (limit,)))


def verify_log_chain() -> tuple[bool, int | None]:
    """(True, None) if untouched, else (False, id of the first broken entry)."""
    with conn() as c:
        rows = _rows(c.execute("SELECT * FROM staff_log ORDER BY id"))
    prev = "GENESIS"
    for r in rows:
        expected = _hash(prev, r["staff_id"], r["action"], r["candidate_id"], r["detail"], r["created_at"])
        if r["prev_hash"] != prev or r["hash"] != expected:
            return False, r["id"]
        prev = r["hash"]
    return True, None


def override_counts() -> list[dict]:
    """Overrides per staff member: a high count can point to insider help."""
    with conn() as c:
        return _rows(c.execute(
            "SELECT staff_id, COUNT(*) AS overrides FROM staff_log WHERE action LIKE 'override%' "
            "GROUP BY staff_id ORDER BY overrides DESC"))
