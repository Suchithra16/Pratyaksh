"""Words check: did the candidate actually say the challenge sentence?

DetectifAI checks WHO is speaking and whether the voice is REAL, but not WHAT was said.
Without this check, someone could replay an old recording of the real candidate.

Uses the free Whisper model locally (pip install faster-whisper). If it isn't installed,
the check is skipped and the result says "not checked" - the app still works.
"""

from __future__ import annotations

import difflib
import io
import re

from . import config

_model = None
_load_error: str | None = None

_DIGIT_WORDS = {"zero": "0", "oh": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
                "six": "6", "seven": "7", "eight": "8", "nine": "9"}


def available() -> bool:
    if config.WORDS_CHECK_ENABLED == "off":
        return False
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False


def status_text() -> str:
    if config.WORDS_CHECK_ENABLED == "off":
        return "Words check switched off in settings"
    if not available():
        return "Words check not installed (pip install faster-whisper)"
    if _load_error:
        return f"Words check failed to load: {_load_error}"
    return f"Words check on (Whisper {config.WHISPER_MODEL})"


def _get_model():
    global _model, _load_error
    if _model is None:
        from faster_whisper import WhisperModel

        try:
            _model = WhisperModel(config.WHISPER_MODEL, device="cpu", compute_type="int8")
        except Exception as e:  # first run downloads the model; may fail offline
            _load_error = str(e)
            raise
    return _model


def normalise(text: str) -> list[str]:
    text = text.lower()
    text = re.sub(r"[^a-z0-9 ]+", " ", text)
    tokens = []
    for tok in text.split():
        if tok in _DIGIT_WORDS:
            tokens.append(_DIGIT_WORDS[tok])
        elif tok.isdigit():
            tokens.extend(list(tok))  # "4719" -> 4 7 1 9
        else:
            tokens.append(tok)
    return tokens


def similarity(expected: str, heard: str) -> float:
    a, b = normalise(expected), normalise(heard)
    if not a:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def transcribe(audio: bytes) -> str:
    model = _get_model()
    segments, _info = model.transcribe(io.BytesIO(audio), language="en", beam_size=1)
    return " ".join(seg.text.strip() for seg in segments).strip()


def check(audio: bytes, expected: str) -> dict:
    """Returns {"checked": bool, "ok": bool|None, "score": float|None, "transcript": str|None, "note": str}."""
    if not available():
        return {"checked": False, "ok": None, "score": None, "transcript": None, "note": status_text()}
    try:
        heard = transcribe(audio)
    except Exception as e:
        return {"checked": False, "ok": None, "score": None, "transcript": None,
                "note": f"Words check error: {e}"}
    score = similarity(expected, heard)
    return {"checked": True, "ok": score >= config.WORDS_MATCH_THRESHOLD, "score": round(score, 3),
            "transcript": heard, "note": f"{score:.0%} of the sentence matched"}
