"""Stage chains for each exam.

Every candidate moves through a chain of stages. Each stage's voice is compared with the
ANCHOR: the voice of whoever actually wrote the exam (the first supervised exam stage).
Final-gate stages (college reporting, training academy) are stricter: no retries.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Stage:
    key: str
    label: str
    anchor: bool = False  # the supervised exam stage whose voice becomes the reference
    final_gate: bool = False  # nothing becomes final until this matches the anchor


CHAINS = {
    "JEE": [
        Stage("exam_hall", "Exam hall (JEE Main)", anchor=True),
        Stage("next_exam", "Next session / JEE Advanced"),
        Stage("counselling_docs", "Counselling document verification"),
        Stage("college_reporting", "College reporting day", final_gate=True),
        Stage("first_semester", "First-semester random check"),
    ],
    "NEET": [
        Stage("exam_hall", "Exam hall (NEET-UG)", anchor=True),
        Stage("counselling_docs", "Counselling document verification"),
        Stage("college_reporting", "College reporting day", final_gate=True),
        Stage("first_semester", "First-semester random check"),
    ],
    "UPSC": [
        Stage("prelims", "Prelims exam hall", anchor=True),
        Stage("mains", "Mains exam hall"),
        Stage("interview", "Interview (personality test)"),
        Stage("training_academy", "Training academy joining", final_gate=True),
        Stage("probation", "Probation random check"),
    ],
}

EXAMS = list(CHAINS)


def chain(exam: str) -> list[Stage]:
    return CHAINS[exam]


def get_stage(exam: str, key: str) -> Stage:
    for s in CHAINS[exam]:
        if s.key == key:
            return s
    raise KeyError(f"Unknown stage {key} for {exam}")


def anchor_stage(exam: str) -> Stage:
    return next(s for s in CHAINS[exam] if s.anchor)
