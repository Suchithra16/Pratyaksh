"""DetectifAI API client: Aletheia (deepfake detection) and Eidos (speaker verification).

Two clients share one interface:
  - DetectifClient talks to the real API (uses credits).
  - MockClient returns simulated results for building the UI without spending credits.
    The app shows a clear MOCK MODE banner whenever it is used.

API reference: https://platform.detectif.ai/docs
"""

from __future__ import annotations

import hashlib
import io
import random
import uuid
import wave
from dataclasses import dataclass

import requests

from . import config


class DetectifError(Exception):
    """Raised when the API returns an error. `status` is the HTTP status code."""

    def __init__(self, status: int, code: str, message: str):
        super().__init__(f"{status} {code}: {message}")
        self.status = status
        self.code = code
        self.message = message


# ---------------------------------------------------------------- results ---


@dataclass
class DeepfakeResult:
    verdict: str  # "real" or "fake"
    score: float  # 0..1, higher = more likely AI-generated
    operation_id: str | None
    raw: dict


@dataclass
class VerifyResult:
    speaker_id: str
    decision: str  # "match" or "no_match"
    similarity: float  # -1..1, higher = more alike (not a percentage)
    deepfake: DeepfakeResult | None
    operation_id: str | None
    raw: dict


@dataclass
class EnrollResult:
    speaker_id: str
    samples: int
    speech_seconds: float | None
    duration_seconds: float | None
    operation_id: str | None
    raw: dict


def _parse_deepfake(obj: dict | None, fallback_op: str | None = None) -> DeepfakeResult | None:
    if not obj:
        return None
    if "error" in obj and obj.get("error"):
        return None
    result = obj.get("result", obj)  # detect endpoint nests under "result"; verify does not
    return DeepfakeResult(
        verdict=str(result.get("verdict", "")).lower(),
        score=float(result.get("score", 0.0)),
        operation_id=obj.get("operation_id", fallback_op),
        raw=obj,
    )


# ----------------------------------------------------------- real client ---


class DetectifClient:
    is_mock = False

    def __init__(self, api_key: str | None = None, base_url: str | None = None, timeout: int = 90):
        self.api_key = api_key or config.DETECTIF_API_KEY
        self.base_url = (base_url or config.DETECTIF_BASE_URL).rstrip("/")
        self.timeout = timeout
        if not self.api_key:
            raise ValueError("DETECTIF_API_KEY is not set. Put it in the .env file.")

    # -- low level --
    def _headers(self, idempotent: bool = True) -> dict:
        headers = {"Authorization": f"Bearer {self.api_key}"}
        if idempotent:
            headers["Idempotency-Key"] = str(uuid.uuid4())
        return headers

    def _handle(self, resp: requests.Response) -> dict:
        if resp.status_code >= 400:
            try:
                err = resp.json().get("error", {})
                code = err.get("code", "error")
                message = err.get("message", resp.text[:300])
            except ValueError:
                code, message = "error", resp.text[:300]
            raise DetectifError(resp.status_code, code, message)
        return resp.json()

    def _post_file(self, path: str, audio: bytes, filename: str, fields: dict | None = None) -> dict:
        files = {"file": (filename, audio)}
        resp = requests.post(
            f"{self.base_url}{path}",
            headers=self._headers(),
            files=files,
            data=fields or {},
            timeout=self.timeout,
        )
        return self._handle(resp)

    # -- Aletheia --
    def detect(self, audio: bytes, filename: str = "clip.wav") -> DeepfakeResult:
        data = self._post_file("/v1/deepfake/detect", audio, filename)
        return _parse_deepfake(data)

    # -- Eidos --
    def enroll(self, speaker_id: str, audio: bytes, filename: str = "clip.wav",
               display_name: str | None = None) -> EnrollResult:
        fields = {"speaker_id": speaker_id}
        if display_name:
            fields["display_name"] = display_name[:128]
        data = self._post_file("/v1/speakers/enroll", audio, filename, fields)
        speaker = data.get("speaker", {})
        quality = data.get("quality", {}) or {}
        return EnrollResult(
            speaker_id=speaker.get("speaker_id", speaker_id),
            samples=int(speaker.get("samples", 0)),
            speech_seconds=quality.get("speech_seconds"),
            duration_seconds=quality.get("duration_seconds"),
            operation_id=data.get("operation_id"),
            raw=data,
        )

    def verify(self, speaker_id: str, audio: bytes, filename: str = "clip.wav",
               detect_deepfake: bool = True, role: str = "target") -> VerifyResult:
        # `role` is only used by MockClient; the real API ignores it.
        fields = {"speaker_id": speaker_id, "detect_deepfake": "true" if detect_deepfake else "false"}
        data = self._post_file("/v1/speakers/verify", audio, filename, fields)
        result = data.get("result", {})
        return VerifyResult(
            speaker_id=data.get("speaker_id", speaker_id),
            decision=str(result.get("decision", "")).lower(),
            similarity=float(result.get("similarity", 0.0)),
            deepfake=_parse_deepfake(data.get("deepfake")),
            operation_id=data.get("operation_id"),
            raw=data,
        )

    def get_speaker(self, speaker_id: str) -> dict | None:
        resp = requests.get(f"{self.base_url}/v1/speakers/{speaker_id}",
                            headers=self._headers(False), timeout=self.timeout)
        if resp.status_code == 404:
            return None
        return self._handle(resp)

    def delete_speaker(self, speaker_id: str) -> bool:
        resp = requests.delete(f"{self.base_url}/v1/speakers/{speaker_id}",
                               headers=self._headers(False), timeout=self.timeout)
        if resp.status_code == 404:
            return False
        return bool(self._handle(resp).get("deleted"))

    # -- account --
    def credits(self) -> dict:
        resp = requests.get(f"{self.base_url}/v1/credits", headers=self._headers(False), timeout=30)
        return self._handle(resp)

    def feedback(self, operation_id: str, correct: bool, label: str | None = None,
                 note: str | None = None) -> dict:
        body = {"correct": correct, "label": label, "note": (note or None)}
        resp = requests.post(f"{self.base_url}/v1/operations/{operation_id}/feedback",
                             headers=self._headers(False), json=body, timeout=30)
        return self._handle(resp)


# ----------------------------------------------------------- mock client ---


MOCK_SCENARIOS = {
    "genuine": "The right person, real voice",
    "impostor": "A different person (proxy)",
    "ai_clone": "AI clone of the right person",
    "solver": "Right person, but also matches other candidates",
    "borderline": "Unclear match (noise, cold)",
}


def wav_duration(audio: bytes) -> float | None:
    """Length of a WAV clip in seconds, or None if it isn't a readable WAV."""
    try:
        with wave.open(io.BytesIO(audio)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return None


class MockClient:
    """Simulated DetectifAI. Results follow `scenario` so every demo path can be tested."""

    is_mock = True

    def __init__(self, scenario: str = "genuine"):
        self.scenario = scenario
        self._samples: dict[str, int] = {}

    def _op(self) -> str:
        return "mock_" + uuid.uuid4().hex[:24]

    def _rng(self, audio: bytes, salt: str) -> random.Random:
        seed = int(hashlib.sha256(audio[:4096] + salt.encode()).hexdigest()[:8], 16)
        return random.Random(seed)

    def _fake_df(self, audio: bytes) -> DeepfakeResult:
        rng = self._rng(audio, "df")
        if self.scenario == "ai_clone":
            score = round(rng.uniform(0.82, 0.98), 3)
            verdict = "fake"
        else:
            score = round(rng.uniform(0.02, 0.18), 3)
            verdict = "real"
        return DeepfakeResult(verdict, score, self._op(), {"mock": True})

    def detect(self, audio: bytes, filename: str = "clip.wav") -> DeepfakeResult:
        return self._fake_df(audio)

    def enroll(self, speaker_id: str, audio: bytes, filename: str = "clip.wav",
               display_name: str | None = None) -> EnrollResult:
        dur = wav_duration(audio)
        if dur is not None and dur < 15:
            raise DetectifError(422, "insufficient_speech",
                                f"Enrollment needs 15-60 s of audio (got {dur:.1f} s).")
        n = self._samples.get(speaker_id, 0)
        if n >= 5:
            raise DetectifError(409, "sample_limit", "A speaker can have at most 5 samples.")
        self._samples[speaker_id] = n + 1
        return EnrollResult(speaker_id, n + 1, (dur or 18.0) * 0.9, dur or 18.0, self._op(), {"mock": True})

    def verify(self, speaker_id: str, audio: bytes, filename: str = "clip.wav",
               detect_deepfake: bool = True, role: str = "target") -> VerifyResult:
        dur = wav_duration(audio)
        if dur is not None and dur < 3:
            raise DetectifError(422, "insufficient_speech", f"Verify needs at least 3 s (got {dur:.1f} s).")
        rng = self._rng(audio, speaker_id)
        s = self.scenario
        if role == "cross":
            match = s == "solver"
        elif s in ("genuine", "ai_clone", "solver"):
            match = True
        elif s == "borderline":
            match = rng.random() < 0.5
        else:  # impostor
            match = False
        if s == "borderline":
            sim = round(rng.uniform(0.40, 0.55), 4)
        else:
            sim = round(rng.uniform(0.66, 0.86), 4) if match else round(rng.uniform(0.05, 0.30), 4)
        df = self._fake_df(audio) if detect_deepfake else None
        return VerifyResult(speaker_id, "match" if match else "no_match", sim, df, self._op(), {"mock": True})

    def get_speaker(self, speaker_id: str) -> dict | None:
        n = self._samples.get(speaker_id)
        return {"speaker_id": speaker_id, "samples": n} if n else None

    def delete_speaker(self, speaker_id: str) -> bool:
        return self._samples.pop(speaker_id, None) is not None

    def credits(self) -> dict:
        return {"plan": "mock", "available": None, "price_per_operation": 0, "unlimited": True}

    def feedback(self, operation_id: str, correct: bool, label: str | None = None,
                 note: str | None = None) -> dict:
        return {"operation_id": operation_id, "correct": correct, "label": label, "note": note}


def get_client(force_mock: bool | None = None, scenario: str = "genuine"):
    use_mock = config.MOCK_MODE if force_mock is None else force_mock
    if use_mock:
        return MockClient(scenario)
    return DetectifClient()
