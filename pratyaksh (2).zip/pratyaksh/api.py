"""Pratyaksh - FastAPI backend (for integrations: exam-body systems, kiosks, and later live phone calls).

Run:  uvicorn api:app --reload --port 8000      then open http://localhost:8000/docs

The Streamlit app calls the same service functions directly, so you don't need this running for the demo.
"""

from __future__ import annotations

from dataclasses import asdict

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from pydantic import BaseModel

from pratyaksh import config, db, service
from pratyaksh.detectif import DetectifError, get_client

db.init_db()
client = get_client()
app = FastAPI(title="Pratyaksh API", version="0.1.0",
              description="The same person, in person, at every stage of an exam.")


def _err(e: Exception):
    if isinstance(e, DetectifError):
        raise HTTPException(502, f"DetectifAI: {e}")
    raise HTTPException(400, str(e))


class CandidateIn(BaseModel):
    roll: str
    name: str
    exam: str
    centre: str = ""
    phone: str = ""
    device_id: str = ""
    is_minor: bool = False
    consent_by: str = ""
    staff_id: str = "api"


class StartCheckIn(BaseModel):
    roll: str
    stage: str


class ClearIn(BaseModel):
    officer_1: str
    officer_2: str
    note: str
    provisional: bool = True


@app.get("/health")
def health():
    return {"ok": True, "mock": client.is_mock}


@app.get("/credits")
def credits():
    try:
        return client.credits()
    except DetectifError as e:
        _err(e)


@app.post("/candidates")
def create_candidate(body: CandidateIn):
    try:
        return service.register(body.roll, body.name, body.exam, body.centre, body.phone, body.device_id,
                                body.is_minor, body.consent_by, body.staff_id)
    except service.PratyakshError as e:
        _err(e)


@app.get("/candidates")
def candidates():
    return db.list_candidates()


@app.get("/candidates/{roll}/timeline")
def candidate_timeline(roll: str):
    try:
        tl = service.timeline(roll)
    except service.PratyakshError as e:
        _err(e)
    tl["chain"] = [asdict(s) for s in tl["chain"]]
    return tl


@app.post("/candidates/{roll}/enroll")
async def enroll(roll: str, style: str = Form(...), staff_id: str = Form("api"), file: UploadFile = File(...)):
    try:
        return service.enroll_sample(client, roll, style, await file.read(), file.filename or "clip.wav", staff_id)
    except (service.PratyakshError, DetectifError) as e:
        _err(e)


@app.post("/checks/start")
def start_check(body: StartCheckIn):
    try:
        return service.start_check(body.roll, body.stage)
    except (service.PratyakshError, KeyError) as e:
        _err(e)


@app.post("/checks/{challenge_id}")
async def submit_check(challenge_id: int, staff_id: str = Form("api"), hoarse: bool = Form(False),
                       file: UploadFile = File(...), photo: UploadFile | None = File(None)):
    try:
        return service.run_check(client, challenge_id, await file.read(), file.filename or "clip.wav", staff_id,
                                 hoarse, await photo.read() if photo else None)
    except (service.PratyakshError, DetectifError) as e:
        _err(e)


@app.post("/candidates/{roll}/clear")
def clear(roll: str, body: ClearIn):
    try:
        service.manual_clear(roll, body.officer_1, body.officer_2, body.note, body.provisional)
        return {"ok": True, "status": db.get_candidate(roll)["status"]}
    except service.PratyakshError as e:
        _err(e)


@app.get("/alerts")
def alerts():
    return db.list_alerts()


@app.get("/audit/verify")
def audit_verify():
    ok, bad = db.verify_log_chain()
    return {"intact": ok, "first_broken_entry": bad}


@app.get("/settings")
def settings():
    return {"mock": client.is_mock, "max_retries": config.MAX_RETRIES, "cross_check_limit": config.CROSS_CHECK_LIMIT,
            "challenge_ttl_seconds": config.CHALLENGE_TTL_SECONDS}
